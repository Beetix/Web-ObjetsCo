<header>
	<h1> Connectif </h1>
	<?php
		
		include('menu.php');
	?>
</header>